package project1;

import java.util.Scanner;

class MiniProjectDriver 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the School name:");
		String schname1=sc.next();
		System.out.println("Enter the School location:");
		String loc=sc.next();
		System.out.println("Enter the principal name:");
		String princi=sc.next();
		
		School sch=new School(schname1,loc,princi);
		boolean control=true;
		while(control)
		{
		System.out.println("Enter the option: \n 1 ==> ADMIT STUDENT \n 2 ==> REMOVE STUDENT \n 3 ==>SCHOOL DETAILS \n 4 ==> STUDENT DETAILS \n 5 ==>EXIT ");
		int option=sc.nextInt();
		
		switch(option)
		{
		case 1:
		{
			sch.admitStudent();
		}
		break;
		case 2:
		{
			sch.removeStudent();
		}
		break;
		case 3:
		{
			sch.schoolDetails();
		}
		break;
		case 4:
		{
			sch.stu.studentDetails();
		}
		break;
		case 5:
		{
			control=false;
			System.out.println(" EXIT ");
		}
		break;
		default:
		{
			System.out.println("Please enter valid option!");
		}
	  }
	}
  }

}

class Student
{
	String sname;
	int sid;
	long cno;
	double percentage;
	
	
	
	public String getSname()
	{
		return sname;
	}
	public int getSid()
	{
		return sid;
	}
	public long getContact()
	{
		return cno;
	}
	public double getPercentage()
	{
		return percentage;
	}
	Student(String sname,int sid,long cno,double percentage)
	{
		this.sname=sname;
		this.sid=sid;
		this.cno=cno;
		this.percentage=percentage;
		
	}
	public void studentDetails()
	{
		System.out.println("********STUDENT DETAILS*********");
		System.out.println("The id of the student:"+sid);
		System.out.println("The name of the student is:"+sname);
		System.out.println("The contanct number of student is:"+cno);
		System.out.println("The percentage of student is:"+percentage);
	}
}



class School
{
	String name;
	String location;
	String principal;
	
	Student stu;
	
	School(String name,String location,String principal)
	{
		this.name=name;
		this.location=location;
		this.principal=principal;
	}
	
	public void admitStudent() 
	{
		if(stu==null)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the student name:");
		String name1=sc.next();
		System.out.println("Enter the id:");
		int id1=sc.nextInt();
		System.out.println("Enter the contact number:");
		long cno1=sc.nextLong();
		System.out.println("Enter the percentage:");
		double percentage1=sc.nextDouble();
		
		stu=new Student(name1, id1, cno1, percentage1);
		System.out.println("*****Student got successfully admitted****");
		}
		else
		{
			System.out.println("Admission is full ..Better luck next time");
		}
	}
	public void removeStudent()
	{
		if(stu!=null)
		{
			stu=null;
			System.out.println("Student removed successfully");
		}
		else
		{
			System.out.println("student does not exist!So do not remove a student");
		}
	}
	public void schoolDetails()
	{
		System.out.println("*********School Details********");
		System.out.println("The name of the class is:"+name);
		System.out.println("The loaction of school is:"+location);
		System.out.println("The principal of the school is:"+principal);
	}
}
